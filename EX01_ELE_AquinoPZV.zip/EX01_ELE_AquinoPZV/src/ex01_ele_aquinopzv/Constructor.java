/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ex01_ele_aquinopzv;

public class Constructor {
    String name;
    String dev;
    double sales;
    int year;
    //String, double, and int
    
    public Constructor(String a, String b, double c, int d) {
        name = a;
        dev = b;
        sales = c;
        year = d;
    }
} 
