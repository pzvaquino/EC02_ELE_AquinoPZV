/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ex02_ele_aquinopzv.EX02_ELE_AquinoPZV;

public class Song {
    String title;
    int timesPlayed;
    double lengthInMinutes;
    
    public Song(String a) {
        title = a;
    }
}
