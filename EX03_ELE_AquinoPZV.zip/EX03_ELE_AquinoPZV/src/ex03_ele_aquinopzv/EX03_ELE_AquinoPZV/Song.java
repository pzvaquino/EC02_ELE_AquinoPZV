/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ex03_ele_aquinopzv.EX03_ELE_AquinoPZV;

public class Song {
    private String name;
    private int timesPlayed;
    
    public Song(String songName) {
        name = songName;
    }
    
    public void perform() {
        timesPlayed++;
    }
    
   //Getters
    public String getSongName() {
        return name;
    }
    
    public int getTimesPlayed() {
        return timesPlayed;
    }
}
