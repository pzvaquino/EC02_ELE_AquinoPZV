/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ex03_ele_aquinopzv.EX03_ELE_AquinoPZV;

public class Venue {
    private String name;
    private int timesUsed;
    
    public Venue(String venueName) {
        name = venueName;
    }
    
    public void perform() {
        timesUsed++;
    }
    
    public String getVenueName() {
        return name;
    }
    
    public int getTimesUsed() {
        return timesUsed;
    }
}

